#include <stdio.h>
#include <stdlib.h>
#include "bitarray.h"
#include "filter.h"

/* Return a pointer to an empty bitarray that can store m bits*/
bitarray *create_bitarray(int m){
    if(m<1) return NULL;
    bitarray *b=(bitarray*) malloc(sizeof(bitarray));
    b->array=(unsigned char*) malloc(sizeof(unsigned char)*m);
    b->size=m;
    clear_bitarray(b);
    return b;
}
/* Free the memory associated with the bitarray */
void free_bitarray(bitarray *a){
    free(a->array);
    free(a);
}
/* Set position pos in the bitarray to 1 */
void set_bitarray(bitarray *a,int pos){
    a->array[pos]=1;
}
/* Set position pos in the bitarray to 0 */
void reset_bitarray(bitarray *a,int pos){
    a->array[pos]=0;
}
unsigned char get_bitarray(bitarray *a,int pos){
    return a->array[pos];
}
void clear_bitarray(bitarray *a){
    int i;
    for(i=0;i<a->size;i++){
        reset_bitarray(a,i);
    }
}