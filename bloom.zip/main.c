#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "bitarray.h"
#include "filter.h"

int main(int argc, char const *argv[])
{
    /* gcc -o main main.c bitarray.o filter.o -lm */
    filter*f=create_filter( 1000, 5);
    add_filter(f,"hello");
    add_filter(f,"nope");
    add_filter(f,"yes");
    add_filter(f,"sleep");
    add_filter(f,"why");

    is_member_filter(f,"sleep")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"yes")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"nope")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"why")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"hello")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"this")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"haha")==1?printf("It's in.\n") : printf("It is not in.\n");
    is_member_filter(f,"what")==1?printf("It's in.\n") : printf("It is not in.\n");
    return 0;
}
