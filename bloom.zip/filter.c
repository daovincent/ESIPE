#include <stdio.h>
#include <stdlib.h>
#include "bitarray.h"
#include "filter.h"

/* Return a pointer to an empty filter with parameters m and k */
filter *create_filter(int m,int k){
    filter* f=(filter*) malloc(sizeof(filter));
    f->weigth=(unsigned int*) malloc(sizeof(unsigned int)*m);
    f->k=k;
    f->array=create_bitarray(m);
    return f;
}

/* Free the memory associated with the filter */
void free_filter(filter* f){
    free_bitarray(f->array);
    free(f->weigth);
    free(f);
}

/* Compute k hash values for the string str 
   and place them in the array hashes*/
void hash(filter* f, char* str,unsigned hashes[]){
    int i,j;
    unsigned h;
    h = 0;
    for(i=0;i<f->k;i++){
        for (j = 0; str[j] != '\0'; j++) {
            h = (f->weigth[i] * h + str[j] )% f->array->size;
        }
        hashes[i]=h;
    }
    
}
/*  Add the key str to the free_filter */
void add_filter(filter* f,char* str){
    unsigned* hashes=(unsigned*) malloc(sizeof(unsigned)*f->k);
    hash(f,str,hashes);
    int i;
    for(i=0;i<f->k;i++) set_bitarray(f->array,hashes[i]);
    free(hashes);
}

/* Check if the key str is in the filter,
   0 means no, 1 means maybe */
int is_member_filter(filter *f, char* str){
    unsigned* hashes=(unsigned*) malloc(sizeof(unsigned)*f->k);
    hash(f,str,hashes);
    int i;
    for(i=0;i<f->k;i++) 
        if(get_bitarray(f->array,hashes[i])==0){
            free(hashes);
            return 0;
        }
    free(hashes);
    return 1;
}